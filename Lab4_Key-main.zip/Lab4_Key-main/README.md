# Lab4_Key

## For this key, I have posted a set of various scripts that all function basically the same way - they recreate the first capstone project

* The first script is the one we made together during a walk-through in class:
  * [DocS.script.sh](https://github.com/AUCompBio-Fall23/Lab4_Key/blob/main/DocS.script.sh)
   
* Here is another example using a for loop:
  * [for_cp1.sh](https://github.com/AUCompBio-Fall23/Lab4_Key/blob/main/for_cp1.sh)

* An example script using a while loop:
  * [while_cp1.sh](https://github.com/AUCompBio-Fall23/Lab4_Key/blob/main/while_cp1.sh)

* An example script that is hard coded to the files:
  * [hardcode_cp1.sh](https://github.com/AUCompBio-Fall23/Lab4_Key/blob/main/hardcode_cp1.sh)
