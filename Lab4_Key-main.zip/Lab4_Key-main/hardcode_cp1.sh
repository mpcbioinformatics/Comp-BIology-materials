#! /bin/bash

## HARD CODED SCRIPT

# Project setup
mkdir DocS_Project1
mkdir -p DocS_Project1/DOM
mkdir -p DocS_Project1/CAST
## copy files to species specific directory
cp 0008658-160822134323880.csv DocS_Project1/DOM/
cp 0008659-160822134323880.csv DocS_Project1/CAST/
## make readme
touch DocS_Project1/DocS.README.txt

# DOM files
cd DocS_Project1/DOM/
## getting the header line
head -1 0008658-160822134323880.csv > DOM_header.txt
## total lines in file
csvline=`cat 0008658-160822134323880.csv|wc -l`
## records in file (no header count)
totline=`echo "scale=3; ${csvline} - 1"|bc`
## lines without the header
tail -${totline} 0008658-160822134323880.csv > DOM.csv

## lat uniq
sort -nk17,17 DOM.csv |uniq > DOM_lat_uniq.txt
## lat long uniq
sort -nk18,18 DOM_lat_uniq.txt |uniq > DOM_lat_long_uniq.txt
## calculations of percent unique and duplicate
latlongline=`cat DOM_lat_long_uniq.txt | wc -l` 
peruni=`echo "scale=4; (${latlongline}/${totline})* 100"| bc`
perdup=`echo "scale=2; 100 - ${peruni}" |bc`
## usnm records
grep "USNM" DOM_lat_long_uniq.txt > DOM_USNM.txt
## percent usnm records
usnmline=`cat DOM_USNM.txt|wc -l`
perusnm=`echo "scale=4; (${usnmline}/${totline})* 100"| bc`

## isolate lat long coords and clean up empty lines
awk 'FS="\t" {print $17, $18}' DOM_USNM.txt >DOM_USNM_lat_long.txt
grep -v "^\s*$" DOM_USNM_lat_long.txt > DOM_lat_long_cleaned.txt

## write numbers to readme file
echo "The percent duplication of records in the DOM files was ${perdup}." >> ../DocS.README.txt
echo >> ../DocS.README.txt
echo "The percent USNM collected records in the DOM files was ${perusnm}" >> ../DocS.README.txt
echo >> ../DocS.README.txt

# CAST files
## comments for steps in DOM section
cd ../CAST/
head -1 0008659-160822134323880.csv > CAST_header.txt
csvline=`cat 0008659-160822134323880.csv|wc -l`
totline=`echo "scale=3; ${csvline} - 1"|bc`
tail -${totline} 0008659-160822134323880.csv > CAST.csv

sort -nk17,17 CAST.csv |uniq > CAST_lat_uniq.txt
sort -nk18,18 CAST_lat_uniq.txt |uniq > CAST_lat_long_uniq.txt
latlongline=`cat CAST_lat_long_uniq.txt | wc -l`
peruni=`echo "scale=4; (${latlongline}/${totline})* 100"| bc`
perdup=`echo "scale=2; 100 - ${peruni}" |bc`
grep "USNM" CAST_lat_long_uniq.txt > CAST_USNM.txt
usnmline=`cat CAST_USNM.txt|wc -l`
perusnm=`echo "scale=4; (${usnmline}/${totline})* 100"| bc`

awk 'FS="\t" {print $17, $18}' CAST_USNM.txt > CAST_USNM_lat_long.txt
grep -v "^\s*$" CAST_USNM_lat_long.txt > CAST_lat_long_cleaned.txt

echo "The percent duplication of records in the CAST files was ${perdup}." >> ../DocS.README.txt
echo >> ../DocS.README.txt
echo "The percent USNM collected records in the CAST files was ${perusnm}" >> ../DocS.README.txt
echo >> ../DocS.README.txt

# final files
cd ..
## create combined file 
cat CAST/CAST_lat_long_cleaned.txt DOM/DOM_lat_long_cleaned.txt > Lat_Long_USNM_combined.txt
