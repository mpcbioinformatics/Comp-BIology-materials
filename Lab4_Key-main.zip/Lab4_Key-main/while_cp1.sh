#! /bin/bash

## WHILE LOOP SCRIPT

# Project setup
mkdir DocS_Project1

## make readme
touch DocS_Project1/DocS.README.txt

# get list of csv files
ls *.csv > filelist.txt

while read i 
do

## determine subspecies name
taxon=`cut -f 11 ${i}|tail -1`

## test for subspecies label
if [[ ${taxon} == castaneus ]]
then
species="CAST"
elif [[ ${taxon} == domesticus ]]
then
species="DOM"
else
species=${taxon}
fi

## subspecies directory set up
mkdir -p DocS_Project1/${species}
cp ${i} DocS_Project1/${species}/
cd DocS_Project1/${species}/

## getting the header line
head -1 ${i} > ${species}_header.txt

## total lines in file
csvline=`cat ${i}|wc -l`

## records in file (no header count)
totline=`echo "scale=3; ${csvline} - 1"|bc`

## lines without the header
tail -${totline} ${i} > ${species}.csv

## lat uniq
sort -nk17,17 ${species}.csv |uniq > ${species}_lat_uniq.txt

## lat long uniq
sort -nk18,18 ${species}_lat_uniq.txt |uniq > ${species}_lat_long_uniq.txt

## calculations of percent unique and duplicate
latlongline=`cat ${species}_lat_long_uniq.txt | wc -l` 
peruni=`echo "scale=4; (${latlongline}/${totline})* 100"| bc`
perdup=`echo "scale=2; 100 - ${peruni}" |bc`

## usnm records
grep "USNM" ${species}_lat_long_uniq.txt > ${species}_USNM.txt

## percent usnm records
usnmline=`cat ${species}_USNM.txt|wc -l`
perusnm=`echo "scale=4; (${usnmline}/${totline})* 100"| bc`

## isolate lat long coords and clean up empty lines
awk 'FS="\t" {print $17, $18}' ${species}_USNM.txt > ${species}_USNM_lat_long.txt
grep -v "^\s*$" ${species}_USNM_lat_long.txt > ${species}_lat_long_cleaned.txt

## copy cleaned file to main directory for combining
cp ${species}_lat_long_cleaned.txt ../

## write numbers to readme file
echo "The percent duplication of records in the ${species} files was ${perdup}." >> ../DocS.README.txt
echo >> ../DocS.README.txt
echo "The percent USNM collected records in the ${species} files was ${perusnm}" >> ../DocS.README.txt
echo >> ../DocS.README.txt

cd ../..

done < filelist.txt

## create combined file 
cd DocS_Project1/
cat *_lat_long_cleaned.txt > Lat_Long_USNM_combined.txt

## remove extra files
rm *_lat_long_cleaned.txt
rm ../filelist.txt
