#!/bin/bash

# Setting up file structure with DOM and CAST in the project folder
mkdir -p DocS_Project1

for species in 'DOM' 'CAST'
do
    mkdir -p DocS_Project1/$species
    echo $species
# Looking at the effects of chopping the screen instead of folding (soft-wrapping) ; checking to see which subspecies is in this dataset
#   22  less 0008658-160822134323880.csv 
#   23  man less
#   24  less -S 0008658-160822134323880.csv 
# Putting the correct dataset in the correct subdirectory

    if [ $species == "DOM" ]; then
	file=`grep -il "domesticus" *.csv`
	echo "The file for $species is $file"
    elif [ $species == "CAST" ]; then
	file=`grep -il "castaneus" *.csv`
	echo "The file for $species is $file"
    fi

#done

#exit
#    grep -il "domesticus" 0008658-160822134323880.csv
    cp $file DocS_Project1/$species/

   #   26  cp 0008659-160822134323880.csv DocS_Project1/CAST/
# Moving into DOM directory 
    cd DocS_Project1/$species/
# Copying header into new file, removing the header, checking to make sure it worked
   head -1 $file > ${species}_header.txt
#   29  nano 0008658-160822134323880.csv 
#   30  less -S 0008658-160822134323880.csv
# Determining column number for latitude and longitude from header file 
#   31  less -S DOM_header.txt 
# Sorting the file by latitude and using intermediate file "lat_sorted.txt" (removed)
#  sort -nk17,17 $file
  sort -nk17,17 $file > lat_sorted.txt
  uniq lat_sorted.txt > ${species}_lat_uniq.txt
  rm lat_sorted.txt
# Sorting the file by latitude, using a one-liner
#   36  sort -nk17,17 0008658-160822134323880.csv |uniq > DOM_lat_uniq.txt
# Sorting the previous file by longitude, using a one-liner
    sort -nk18,18 ${species}_lat_uniq.txt | uniq > ${species}_lat_long_uniq.txt
# Counting number of lines in original and sorted files
   org_len=$(wc -l $file | awk '{print $1}')
   #wc -l DOM_lat_uniq.txt 
   end_len=`wc -l ${species}_lat_long_uniq.txt | awk '{print $1}'`
   echo $org_len $end_len
   # Using BC calculator (use man bc for syntax and options) to determine percent duplicated records
   
   echo "scale=4; 100 - ($end_len/$org_len)* 100"| bc



   # Grabbing records that include "USNM" using 'grep' and redirecting it into file; Counting lines to compare USNM collected vs all
   grep "USNM" ${species}_lat_long_uniq.txt > ${species}_USNM.txt
#   wc -l DOM_USNM.txt 
# Getting columns (fields) 17 and 18, which should be lat and long using a tab as the field-separator (\t)
   awk 'FS="\t" {print $17, $18}' ${species}_USNM.txt >${species}_USNM_lat_long.txt
# Grabbing only records that DO NOT (-v) begin (^)with a space (\s), repeated zero or more times (*), until the end of the line ($) [A blank line!] 
   grep -v "^\s*$" ${species}_USNM_lat_long.txt > ${species}_lat_long_cleaned.txt
# Sanity Checking result, removing line that isn't a lat,long
#   46  less DOM_USNM_lat_long.txt 
#   47  less DOM_lat_long_cleaned.txt 
#   48  nano DOM_lat_long_cleaned.txt 
# Repeating these steps for the other subspecies
  cd ../../

done

cd DocS_Project1/
  cat CAST/CAST_lat_long_cleaned.txt DOM/DOM_lat_long_cleaned.txt > Lat_Long_USNM_combined.txt
# Redirecting history to file
#  history > DocS.history.txt
